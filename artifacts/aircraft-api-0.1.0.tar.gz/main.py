#!/usr/bin/env python3
"""aircraft-api - the example out-of-band gobbler module (docs/cards/P4-06).

A deliberately small, stdlib-only (urllib) source module that proves the signed
repository pipeline end to end: it ships as a .tar.gz artifact in the module
repo, installs out-of-band via the module center, and - once the AIS decoder is
also installed - lights up the "combined ship + aircraft situational picture"
unlock declared in its manifest.

It speaks exactly the frozen module contract (docs/specs/phase2.md §2, §5):
reads the GOBBLER_* env handshake, polls a free/keyless public ADS-B API, and
POSTs aircraft as observations under its own `aircraft-api` source. Snapshot
data - a failed POST is dropped and superseded by the next poll (§8 semantics).
"""

import json
import os
import sys
import time
import urllib.error
import urllib.request

API_URL = "https://api.adsb.lol/v2/mil"  # free, keyless public endpoint
USER_AGENT = "gobbler-aircraft-api/0.1.0 (+https://github.com/gobbler-radio)"


def env(name, default=""):
    return os.environ.get(name, default)


def poll_seconds():
    raw = env("GOBBLER_SETTING_POLL_SECONDS", "30")
    try:
        return max(5, int(raw))
    except ValueError:
        return 30


def fetch_aircraft():
    req = urllib.request.Request(API_URL, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=15) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    return payload.get("ac", []) or []


def to_observation(ac):
    obs = {
        "source": "aircraft-api",
        "model": ac.get("t") or ac.get("desc") or "aircraft",
        "device_id": ac.get("hex", ""),
        "payload": ac,
    }
    if isinstance(ac.get("lat"), (int, float)):
        obs["lat"] = ac["lat"]
    if isinstance(ac.get("lon"), (int, float)):
        obs["lon"] = ac["lon"]
    return obs


def post(api, module_id, token, observations):
    url = api.rstrip("/") + "/api/v0/modules/" + module_id + "/observations"
    body = json.dumps({"observations": observations}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=15) as resp:
        return resp.status


def main():
    api = env("GOBBLER_API")
    module_id = env("GOBBLER_MODULE_ID", "aircraft-api")
    token = env("GOBBLER_MODULE_TOKEN")
    if not api or not token:
        print("aircraft-api: missing GOBBLER_API / GOBBLER_MODULE_TOKEN", file=sys.stderr)
        return 1

    interval = poll_seconds()
    while True:
        try:
            aircraft = fetch_aircraft()
            batch = [to_observation(ac) for ac in aircraft if ac.get("hex")][:1000]
            if batch:
                post(api, module_id, token, batch)
                print("aircraft-api: posted %d aircraft" % len(batch), file=sys.stderr)
        except (urllib.error.URLError, ValueError, KeyError) as exc:
            # Snapshot data: drop this poll, the next one supersedes it.
            print("aircraft-api: poll failed: %s" % exc, file=sys.stderr)
        time.sleep(interval)


if __name__ == "__main__":
    sys.exit(main())
